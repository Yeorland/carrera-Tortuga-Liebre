/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package principal;

/**
 *
 * @author usuario
 */
public class Liebre extends Thread{
    private final Tablero elTablero;
	
	public Liebre(Tablero elTablero){
		
		this.elTablero = elTablero;
	}
	
	@Override
	public void run() {
		
		   while (!elTablero.getFin()) {
			   
			   elTablero.moverLiebre();
			   try {
				sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}
}
